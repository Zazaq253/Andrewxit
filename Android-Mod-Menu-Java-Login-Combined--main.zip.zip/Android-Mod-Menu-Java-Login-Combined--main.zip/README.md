# Android-Mod+Menu-Java-Login-(Combined)

This is the combined Android Mod Menu + Java Login Project
Mod Menu project credits given to @LGL

# How to add my server?

Open the main activity of the project and find this line.

public static String URL = "https://example.com/login.php"; (Probably in line 52)

Here you can add your server URL

# Where Can I get the server Templete

Goto :- https://github.com/PMTDVA/PHP-Web-Server

Also there is a Video Tutorial for that

Video Tutorial:-
